enum Store { none, playStore, amazon, appStore }
