### Version of flutter_inapp_purchase

### Platforms you faced the error (IOS or Android or both?)

### Expected behavior

### Actual behavior

### Tested environment (Emulator? Real Device?)

### Steps to reproduce the behavior
